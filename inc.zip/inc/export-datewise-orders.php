<?php

function add_export_datewise_orders_button()
{
?>
    <script>
        (function($) {
            

        })(jQuery)
    </script>
<?php
}
add_action('admin_footer', 'add_export_datewise_orders_button');

// AJAX handler to export orders between dates
add_action('wp_ajax_export_orders_between_dates', 'export_orders_between_dates');
function export_orders_between_dates()
{
    check_ajax_referer('export_orders_nonce', 'security');
    $start_date = isset($_POST['start_date']) ? sanitize_text_field($_POST['start_date']) : '';
    $end_date = isset($_POST['end_date']) ? sanitize_text_field($_POST['end_date']) : '';
    if (empty($start_date) || empty($end_date)) {
        wp_die('Please provide both start and end dates.');
    }
    // Retrieve orders between the specified dates
    $args = array(
        'post_type'      => 'shop_order',
        'post_status'    => array('wc-completed', 'wc-processing'), // Adjust statuses as needed
        'date_query'     => array(
            'after'     => $start_date,
            'before'    => $end_date,
            'inclusive' => true,
        ),
        'posts_per_page' => -1,
    );
    $orders = wc_get_orders($args);
    // Generate CSV file
    if (!empty($orders)) {
        $order_data = array();
        foreach ($orders as $order) {
            $order_id = $order->get_id();
            $items = $order->get_items();

            foreach ($items as $item) {
                $product_id = $item->get_product_id();
                $product = $item->get_product();
                // Extract order data and product information
                $order_data[] = array(
                    'Product ID'    => $product_id,
                    'Order ID'      => $order_id,
                    'Order Date'    => $order->get_date_created()->format('Y-m-d H:i:s'),
                    'Customer Name' => $order->get_billing_first_name() . ' ' . $order->get_billing_last_name(),
                    'Customer Email' => $order->get_billing_email(),
                    'Product Name'  => $product ? $product->get_name() : '',
                    'Product SKU'   => $product ? $product->get_sku() : '',
                    'Product Status' => $product ? $product->get_status() : '',
                    'Product Total' => $order->get_total(),
                    'Quantity'      => $item->get_quantity(),
                    'Order Status'  => $order->get_status(),
                );
            }
        }
        $csv_filename = 'exported_orders_between_' . $start_date . '_and_' . $end_date . '.csv';
        // Prepare CSV data
        ob_clean();
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $csv_filename . '"');
        $output = fopen('php://output', 'w');
        fputcsv($output, array('Product ID', 'Order ID', 'Order Date', 'Customer Name', 'Customer Email', 'Product Name', 'Product SKU', 'Product Status', 'Product Total', 'Quantity', 'Order Status')); // CSV headers
        foreach ($order_data as $row) {
            fputcsv($output, $row);
        }
        fclose($output);
        exit;
    } else {
        wp_die('No orders found between the selected dates.');
    }
}
