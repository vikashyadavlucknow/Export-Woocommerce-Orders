<?php
// AJAX handler for exporting filtered orders with multiple filters
add_action('wp_ajax_export_filtered_orders', 'export_filtered_orders');
add_action('wp_ajax_nopriv_export_filtered_orders', 'export_filtered_orders');

function export_filtered_orders()
{
  // Check user's permission to export orders
  if (!current_user_can('manage_options')) {
    wp_die('Permission denied.');
  }
  // Retrieve filter parameters from AJAX request
  $post_status = isset($_GET['post_status']) ? sanitize_text_field($_GET['post_status']) : '';
  $category = isset($_GET['wfobpp_by_category']) ? sanitize_text_field($_GET['wfobpp_by_category']) : '';
  $productid = isset($_GET['wfobpp_by_product']) ? sanitize_text_field($_GET['wfobpp_by_product']) : '';
  $bydate = isset($_GET['filter-by-date']) ? sanitize_text_field($_GET['filter-by-date']) : '';
  $customerUser = isset($_GET['_customer_user']) ? sanitize_text_field($_GET['_customer_user']) : '';

  // Set up arguments for filtering orders
  $args = array(
    'post_type'     => 'shop_order',
    'post_status'   => $post_status,
    'posts_per_page' => -1,
  );

  if (!empty($category)) {
    $args['meta_query'][] = array(
      'key'     => '_wfobpp_product_cats',
      'value'   => $category,
      'compare' => 'LIKE',
    );
  }

  if (!empty($productid)) {
    $args['meta_query'][] = array(
      'key'     => '_wfobpp_product_id',
      'value'   => $productid,
      'compare' => '=',
    );
  }

  if (!empty($customerUser)) {
    $args['_customer_user'] = $customerUser;
  }
  
  if (!empty($bydate) && $bydate !== 0) {
    // Extract year and month from the selected date
    list($year, $month) = explode('-', $bydate);

    $args['date_query'] = array(
      'relation' => 'AND',
      array(
        'year'     => $year,
        'month'    => $month,
      ),
    );
  }

  // Retrieve orders based on applied filters
  $orders = wc_get_orders($args);
  // Generate CSV file
  if (!empty($orders)) {
    $csv_filename = 'exported_filtered_orders_' . date('Y-m-d') . '.csv';
    $csv_output = "Product ID,Order ID,Order Date,Customer Name,Customer Email,Product Name,Product SKU,Product Status,Product Total,Quantity,Order Status\n"; // CSV headers
    foreach ($orders as $order) {
      $items = $order->get_items();
      foreach ($items as $item) {
        $product_id = $item->get_product_id();
        $product = wc_get_product($product_id);
        if (($category && has_term($category, 'product_cat', $product_id)) ||
          ($productid && $product_id == $productid) ||
          ($customerUser && $order->get_customer_id() == $customerUser)
        ) {
          // Include this item's details in the CSV output
          $csv_output .= $product_id . ',';
          $csv_output .= $order->get_id() . ',';
          $csv_output .= $order->get_date_created()->format('Y-m-d H:i:s') . ',';
          $csv_output .= $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() . ',';
          $csv_output .= $order->get_billing_email() . ',';
          $csv_output .= $product ? $product->get_name() . ',' : 'N/A,';
          $csv_output .= $product ? $product->get_sku() . ',' : 'N/A,';
          $csv_output .= $product ? $product->get_status() . ',' : 'N/A';
          $csv_output .= $order->get_total() . ',';
          $csv_output .= $item->get_quantity() . ',';
          $csv_output .= $order->get_status() . ',';
          $csv_output .= "\n";
        }
      }
    }
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $csv_filename . '"');
    echo $csv_output;
    exit;
  } else {
    wp_die('No orders found based on the applied filters.');
  }
}
