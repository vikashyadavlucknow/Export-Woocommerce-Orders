<?php

// Handle AJAX request to export selected products
function export_selected_products_callback()
{
    if (isset($_POST['action']) && $_POST['action'] === 'export_selected_products' && isset($_POST['orders'])) {
        $orders_ids = $_POST['orders'];
        $product_data = array();
        foreach ($orders_ids as $order_id) {
            $order = wc_get_order($order_id);
            $items = $order->get_items();
            $customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            $customer_email = $order->get_billing_email();
            $order_status = $order->get_status();
            $order_id = $order->get_id();
            $orderdate  = $order->get_date_created()->format('Y-m-d H:i:s');
            foreach ($items as $item) {
                $product_id = $item->get_product_id();
                $product = wc_get_product($product_id);
                if ($product) {
                    $product_data[] = array(
                        'Product ID' => $product->get_id(),
                        'Order ID' => $order_id,
                        'Order Date' => $orderdate,
                        'Customer Name' => $customer_name,
                        'Customer Email' => $customer_email,
                        'Product Name' => $product->get_name(),
                        'Product SKU' => $product->get_sku(),
                        'Product Status' => $product->get_status(),
                        'Product Price' => $product->get_price(),
                        'Quantity' => $item->get_quantity(),
                        'Order Status' => $order_status,
                    );
                }
            }
        }

        if (!empty($product_data)) {

            $csv_output = 'Product ID,Order ID,Order Date,Customer Name,Customer Email,Product Name,Product SKU,Product Status,Product Price,Quantity,Order Status' . "\n";
            foreach ($product_data as $product) {
                $csv_output .= '"' . implode('","', $product) . '"' . "\n";
            }
            $file_name = 'selected_products_export_' . date('Y-m-d_H-i-s') . '.csv';
            $upload_dir = wp_upload_dir();
            $file_path = $upload_dir['basedir'] . '/' . $file_name;
            file_put_contents($file_path, $csv_output);
            $file_url = $upload_dir['baseurl'] . '/' . $file_name;
            wp_send_json_success(array('file_url' => $file_url));
        } else {
            wp_send_json_error();
        }
    }
}
add_action('wp_ajax_export_selected_products', 'export_selected_products_callback');